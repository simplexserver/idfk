Third-party runtime dependencies are installed from npm at deploy time.

- wasmoon-lua5.1: MIT. Lua 5.1 WebAssembly runtime for Node.js.
- luaparse: MIT. Lua parser used for syntax/AST analysis.
- lua-format: ISC. Lua formatting/cleanup helper.
- discord.js: Apache-2.0.
- dotenv: BSD-2-Clause.

The project does not vendor the archived WeAreDevs-Deobfuscator repository. Its public documentation was used as research context only. The engine in this project is an independent implementation of the analysis ideas used during our earlier successful traces.

See each installed package's LICENSE file in node_modules for the exact license text.
