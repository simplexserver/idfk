require('dotenv').config();
const fs=require('fs'), path=require('path'), os=require('os');
const {Client,GatewayIntentBits,REST,Routes,SlashCommandBuilder,AttachmentBuilder,EmbedBuilder}=require('discord.js');
const {providers,detect}=require('./providers');

const MANUAL_CONFIG={
  DISCORD_TOKEN:'MTU1ODgyNjA1MjM1NTM2MjkxNg.G-vLhZ.lEX99vs0BmusYjLF-7PQk5gXM3sOU_UHmial7U',
  CLIENT_ID:'1558826052355362916',
  DEV_GUILD_ID:'996075213525618748',
  MAX_FILE_MB:'10',
  ENGINE_TIMEOUT_MS:'900000',
  ENGINE_MAX_RETRIES:'0',
  MAX_CONCURRENT_JOBS:'2'
};
const cfg=(k,d='')=>{const v=MANUAL_CONFIG[k];return v!==undefined&&v!==''&&!String(v).startsWith('PASTE_')?v:(process.env[k]??d)};
const TOKEN=cfg('DISCORD_TOKEN'), CLIENT_ID=cfg('CLIENT_ID'), GUILD=cfg('DEV_GUILD_ID');
const MAX_MB=Number(cfg('MAX_FILE_MB','10')), TIMEOUT=Number(cfg('ENGINE_TIMEOUT_MS','900000')), RETRIES=Number(cfg('ENGINE_MAX_RETRIES','0')), MAX_CONC=Number(cfg('MAX_CONCURRENT_JOBS','2'));
if(!TOKEN||!CLIENT_ID) console.error('Set DISCORD_TOKEN and CLIENT_ID in server.js or environment.');
const client=new Client({intents:[GatewayIntentBits.Guilds]});
let active=0;
function pct(n){return Math.max(1,Math.min(100,Math.round(n)))}
function bar(n){const x=Math.round(n/10);return '█'.repeat(x)+'░'.repeat(10-x)}
function safeName(n){return (n||'deobfuscated.lua').replace(/[^a-zA-Z0-9._-]/g,'_').replace(/\.(txt|lua|luau)$/i,'')+'.lua'}
function classify(report){
 const s=JSON.stringify(report?.static||{}).toLowerCase(), r=report?.runtime||{};
 const labels=[];
 if(report?.static?.vm?.detected) labels.push('VM Script');
 if(/tamper|anti.?tamper|tamper detected|integrity|hookfunction|getgc|debug/.test(s)) labels.push('Anti-Tampering');
 if(report?.static?.obfuscation?.score>=75) labels.push('Extreme Obfuscation');
 else if(report?.static?.obfuscation?.score>=45) labels.push('High Obfuscation');
 else if(report?.static?.obfuscation?.score>=20) labels.push('Moderate Obfuscation');
 else labels.push('Low Obfuscation');
 if(report?.static?.dynamicLoaders>0 || (r.captures||[]).length) labels.push('Dynamic Loading');
 if(/roblox|replicatedstorage|remoteevent|remote function|getservice/.test(s)) labels.push('Roblox Runtime');
 if(report?.static?.luaVersion) labels.push(`Lua ${report.static.luaVersion}`);
 return [...new Set(labels)];
}
function score(report,recovered){
 const st=report?.static||{},rt=report?.runtime||{};
 let n=5;
 if(st.providerConfidence>=90)n+=10; else if(st.providerConfidence>=60)n+=5;
 if(st.vm?.detected)n+=10;
 n+=Math.min(15,Math.floor((st.decodedStringCount||0)/100));
 if((rt.calls||[]).length)n+=10;
 if((rt.captures||[]).length)n+=35;
 if((rt.dynamicStrings||[]).length)n+=10;
 if(recovered&&recovered.length>1000)n+=5;
 if(report?.recoveryKind==='captured-source')return 100;
 if(report?.recoveryKind==='captured-generated-source')return Math.min(99,Math.max(60,n));
 return pct(n);
}
async function register(){
 const commands=[new SlashCommandBuilder().setName('deobfuscate').setDescription('Deobfuscate an authorized Lua/Luau file.').addAttachmentOption(o=>o.setName('file').setDescription('One Lua/Luau file').setRequired(true))].map(x=>x.toJSON());
 const rest=new REST({version:'10'}).setToken(TOKEN);
 if(GUILD) await rest.put(Routes.applicationGuildCommands(CLIENT_ID,GUILD),{body:commands});
 else await rest.put(Routes.applicationCommands(CLIENT_ID),{body:commands});
}
async function run(interaction,file){
 if(active>=MAX_CONC) return interaction.editReply('The deobfuscation engine is busy. Try again shortly.');
 active++;
 try{
  if((file.size||0)>MAX_MB*1024*1024) throw Object.assign(new Error(`File exceeds ${MAX_MB} MB.`),{code:'FILE_TOO_LARGE'});
  const res=await fetch(file.url); if(!res.ok) throw new Error(`Discord download failed: HTTP ${res.status}`);
  const buf=Buffer.from(await res.arrayBuffer());
  const provider=detect(buf.subarray(0,250000).toString('utf8'))||'wearedevs';
  const p=providers.get(provider); if(!p) throw Object.assign(new Error('No installed provider matched this file.'),{code:'PROVIDER_UNAVAILABLE'});
  await interaction.editReply('Deobfuscating with the recovery engine...');
  const result=await p.run({inputBuffer:buf,originalName:file.name,timeoutMs:TIMEOUT,retries:RETRIES});
  const rating=score(result.report,result.recovered);
  const labels=classify(result.report);
  const luaVer=result.report?.static?.luaVersion||'Lua/Luau (detected)';
  const providerLabel=result.providerLabel||'WeAreDevs v1.0.0';
  const recovered=Buffer.from(result.recovered,'utf8');
  const outName=safeName(file.name);
  const embed=new EmbedBuilder().setTitle('Deobfuscation Complete').setDescription(`**Recovery rating:** ${rating}/100\n${bar(rating)}\n\n**Provider:** ${providerLabel}\n**Lua:** ${luaVer}\n**Classification:** ${labels.join(' • ')}`).addFields(
    {name:'Recovery',value:rating===100?'Full precision recovery':'Best evidence-backed reconstruction from decoded + runtime evidence'},
    {name:'Engine',value:`${result.engineVersion||'Deobf Engine'} • ${((result.durationMs||0)/1000).toFixed(1)}s`},
    {name:'Output',value:`${recovered.length.toLocaleString()} bytes • 1 file`}
  ).setFooter({text:'SimpleX Deobf Engine'});
  await interaction.editReply({content:'',embeds:[embed],files:[new AttachmentBuilder(recovered,{name:outName})]});
 }catch(e){
  const msg=e.code==='ENGINE_TIMEOUT'?'The recovery engine timed out.':e.code==='FILE_TOO_LARGE'?e.message:e.message||'Deobfuscation failed.';
  await interaction.editReply(`**Deobfuscation failed**\n${msg}`);
 }finally{active--;}
}
client.once('ready',async()=>{console.log(`Logged in as ${client.user.tag}`);try{await register();console.log('Registered /deobfuscate');}catch(e){console.error('Command registration failed:',e);}});
client.on('interactionCreate',async i=>{if(!i.isChatInputCommand()||i.commandName!=='deobfuscate')return; const file=i.options.getAttachment('file'); await i.deferReply(); await run(i,file);});
client.login(TOKEN);
