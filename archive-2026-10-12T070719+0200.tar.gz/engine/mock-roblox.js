function createRobloxMock(){
  const cache=new Map();
  const recorder={calls:[],callbacks:[],properties:[],returns:[],dynamicStrings:[],call(name,args=[]){if(this.calls.length>=20000)return;this.calls.push({name,args:args.map(safe)})},property(path,key,value){if(this.properties.length<10000)this.properties.push({path,key,value:safe(value)})}};
  function safe(v){if(v===null||v===undefined||typeof v==='string'||typeof v==='number'||typeof v==='boolean')return v;try{return String(v)}catch{return '[object]'}}
  function make(name,opts={}){
    if(cache.has(name)&&!opts.fresh)return cache.get(name);
    const base={__name:name,Name:name.split('.').pop(),ClassName:opts.className||'Folder',Parent:opts.parent||null,Text:'',Value:opts.value,Visible:true,Enabled:true,Health:100,MaxHealth:100,Durability:1000000,Strength:1000,Position:{X:0,Y:0,Z:0},CFrame:{X:0,Y:0,Z:0}};
    let proxy;
    const handler={
      get(target,p){
        if(p==='__raw')return target;if(p==='toString')return()=>`[Mock ${name}]`;
        if(p==='GetService')return service=>{recorder.call(`${name}:GetService`,[service]);return make(`game.${service}`,{className:String(service)})};
        if(p==='HttpGet'||p==='HttpGetAsync')return url=>{recorder.call(`${name}.${p}`,[url]);return `return function() end`};
        if(p==='GetChildren'||p==='GetDescendants')return()=>{recorder.call(`${name}.${p}`,[]);return[]};
        if(p==='GetPlayers')return()=>[make('Players.Player1',{className:'Player'}),make('Players.Player2',{className:'Player'})];
        if(p==='WaitForChild'||p==='FindFirstChild')return child=>make(`${name}.${child}`,{parent:proxy});
        if(p==='FindFirstChildWhichIsA'||p==='FindFirstChildOfClass')return child=>make(`${name}.${child}`,{parent:proxy,className:String(child)});
        if(p==='FindFirstAncestorOfClass')return child=>make(`${name}.Ancestor.${child}`,{className:String(child)});
        if(p==='IsDescendantOf'||p==='IsA')return()=>true;if(p==='IsLoaded')return()=>true;
        if(p==='Destroy')return()=>recorder.call(`${name}.Destroy`,[]);if(p==='Activate')return()=>recorder.call(`${name}.Activate`,[]);
        if(p==='Connect')return fn=>{recorder.callbacks.push({source:name,fn});recorder.call(`${name}.Connect`,[]);return make(`${name}.Connection`,{fresh:true})};
        if(['Tab','Section','Button','Toggle','Dropdown','Paragraph','Select','CreateTab','CreateWindow'].includes(p))return cfg=>{recorder.call(`${name}.${p}`,[cfg&&cfg.Title||cfg&&cfg.Name||'']);if(cfg&&typeof cfg.Callback==='function')recorder.callbacks.push({source:`${name}.${p}`,fn:cfg.Callback,config:cfg});return make(`${name}.${p}.Result`,{fresh:true})};
        if(p==='FireServer'||p==='InvokeServer')return(...a)=>{recorder.call(`${name}.${p}`,a);return true};
        if(['SetCore','CaptureController','ClickButton2','Teleport','SetDesc','Notify','Refresh','SelectTab','Fire','Invoke'].includes(p))return(...a)=>{recorder.call(`${name}.${p}`,a);return make(`${name}.${p}.Result`,{fresh:true})};
        if(['Idled','ChildAdded','ChildRemoved','Changed','Heartbeat','RenderStepped'].includes(p))return make(`${name}.${p}`,{className:'RBXScriptSignal'});
        if(p in target)return target[p];
        const child=make(`${name}.${String(p)}`);return child;
      },
      set(target,p,v){target[p]=v;recorder.property(name,p,v);return true},
      apply(){return proxy}
    };proxy=new Proxy(base,handler);cache.set(name,proxy);return proxy;
  }
  const task=make('task');task.spawn=(fn,...a)=>{recorder.call('task.spawn',[]);if(typeof fn==='function')try{fn(...a)}catch{}return make('task.thread',{fresh:true})};task.defer=task.spawn;task.delay=(t,fn,...a)=>{recorder.call('task.delay',[t]);if(typeof fn==='function')try{fn(...a)}catch{}return make('task.thread',{fresh:true})};task.wait=()=>0;
  const game=make('game',{className:'DataModel'});const workspace=make('workspace',{className:'Workspace'});
  const players=make('Players',{className:'Players'});players.LocalPlayer=make('Players.LocalPlayer',{className:'Player'});players.LocalPlayer.Character=make('Players.LocalPlayer.Character',{className:'Model'});players.LocalPlayer.Character.HumanoidRootPart=make('Players.LocalPlayer.Character.HumanoidRootPart',{className:'Part'});players.LocalPlayer.leaderstats=make('Players.LocalPlayer.leaderstats');players.LocalPlayer.leaderstats.Strength=1000;
  const services={Players:players,ReplicatedStorage:make('ReplicatedStorage'),VirtualUser:make('VirtualUser'),RunService:make('RunService'),UserInputService:make('UserInputService'),StarterGui:make('StarterGui'),CoreGui:make('CoreGui'),HttpService:make('HttpService')};
  services.ReplicatedStorage.rEvents=make('ReplicatedStorage.rEvents');services.ReplicatedStorage.cPetShopFolder=make('ReplicatedStorage.cPetShopFolder');services.ReplicatedStorage.cPetShopRemote=make('ReplicatedStorage.cPetShopRemote');players.LocalPlayer.muscleEvent=make('Players.LocalPlayer.muscleEvent');
  for(const [k,v] of Object.entries(services))cache.set(`game.${k}`,v);game.GetService=s=>services[s]||make(`game.${s}`,{className:String(s)});
  return{game,workspace,services,task,make,recorder};
}
module.exports={createRobloxMock};
