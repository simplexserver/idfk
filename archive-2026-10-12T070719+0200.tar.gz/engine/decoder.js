const crypto = require('crypto');

function luaUnescape(s) {
  return String(s).replace(/\\(\\|"|'|a|b|f|n|r|t|v|z|x[0-9a-fA-F]{2}|\d{1,3})/g, (m, x) => {
    if (x === '\\') return '\\';
    if (x === '"') return '"';
    if (x === "'") return "'";
    const map = { a:'\x07', b:'\b', f:'\f', n:'\n', r:'\r', t:'\t', v:'\v', z:'' };
    if (map[x] !== undefined) return map[x];
    if (x[0] === 'x') return String.fromCharCode(parseInt(x.slice(1), 16));
    return String.fromCharCode(parseInt(x, 10));
  });
}

function scanQuotedStrings(source) {
  const out = [];
  let i = 0;
  while (i < source.length) {
    const q = source[i];
    if (q !== '"' && q !== "'") { i++; continue; }
    const start = i++;
    let raw = '';
    while (i < source.length) {
      const c = source[i++];
      if (c === '\\' && i < source.length) { raw += c + source[i++]; continue; }
      if (c === q) { out.push({ raw, value: luaUnescape(raw), index: start, quote: q }); break; }
      raw += c;
    }
  }
  return out;
}

function scanLongStrings(source) {
  const out = [];
  const re = /\[(=*)\[([\s\S]*?)\]\1\]/g;
  let m;
  while ((m = re.exec(source))) out.push({ raw: m[2], value: m[2], index: m.index, level: m[1].length });
  return out;
}

function extractLuaStrings(source) {
  return scanQuotedStrings(source).concat(scanLongStrings(source)).sort((a,b) => a.index - b.index);
}

function decodeBase64(value) {
  const s = String(value).replace(/\s+/g, '');
  if (s.length < 8 || s.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(s)) return null;
  try {
    const b = Buffer.from(s, 'base64');
    if (!b.length) return null;
    const text = b.toString('utf8');
    if (/�/.test(text)) return null;
    return text;
  } catch { return null; }
}

function decodeHex(value) {
  const s = String(value).replace(/\s+/g, '');
  if (s.length < 8 || s.length % 2 || !/^[0-9a-f]+$/i.test(s)) return null;
  try {
    const text = Buffer.from(s, 'hex').toString('utf8');
    if (/�/.test(text)) return null;
    return text;
  } catch { return null; }
}

function decodeCharCalls(source) {
  const out = [];
  const patterns = [
    /(?:string\.)?char\s*\(([^)]{1,2000})\)/gi,
    /table\.concat\s*\{([^}]{1,2000})\}/gi
  ];
  for (const re of patterns) {
    let m;
    while ((m = re.exec(source))) {
      const body = m[1];
      const nums = [...body.matchAll(/(?:0x[0-9a-f]+|\d{1,3})/gi)].map(x => Number(x[0]));
      if (nums.length >= 2 && nums.every(n => n >= 0 && n <= 255)) {
        const text = String.fromCharCode(...nums);
        if (/[\x09\x0a\x0d\x20-\x7e]/.test(text)) out.push({ value:text, index:m.index, kind:'char-call' });
      }
    }
  }
  return out;
}

function transformCandidates(strings) {
  const candidates = [];
  for (const item of strings) {
    const value = item.value;
    const b64 = decodeBase64(value);
    if (b64 && /[A-Za-z_{}()[\];:=]/.test(b64)) candidates.push({ value:b64, kind:'base64', index:item.index });
    const hex = decodeHex(value);
    if (hex && /[A-Za-z_{}()[\];:=]/.test(hex)) candidates.push({ value:hex, kind:'hex', index:item.index });
  }
  return candidates;
}

function normalizeSource(source) {
  return String(source).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
}

function stripToolHeaders(source) {
  return String(source)
    .replace(/^\s*--\[\[\s*Code generated using github\.com\/Herrtt\/luamin\.js[\s\S]*?\]\]\s*/i, '')
    .replace(/^\s*--\s*Code generated using github\.com\/Herrtt\/luamin\.js\s*$/im, '')
    .trim();
}

function fingerprint(text) { return crypto.createHash('sha256').update(text).digest('hex'); }

module.exports = { luaUnescape, extractLuaStrings, scanQuotedStrings, scanLongStrings, decodeBase64, decodeHex, decodeCharCalls, transformCandidates, normalizeSource, stripToolHeaders, fingerprint };
