const fs=require('fs');
const {Lua}=require('wasmoon-lua5.1');
const luaFormat=require('lua-format');
const {analyzeStatic}=require('./static-analysis');
const {createRobloxMock}=require('./mock-roblox');
const {choose,reconstruction,stripComments}=require('./reconstruction');

function isLua(text){return /\b(local|function|return|for|while|repeat|if)\b|game\s*[:.]|loadstring\s*\(/.test(text)&&text.length>20}
function normalize(text){return stripComments(String(text||'')).replace(/^\s*--\[\[[\s\S]*?\]\]\s*/,'').trim()+'\n'}
async function main(){
  const [input,output,reportPath,mode='full']=process.argv.slice(2);const source=fs.readFileSync(input,'utf8');const started=Date.now();const st=await analyzeStatic(input);const lua=await Lua.create();const mock=createRobloxMock();
  const captures=[];const built=[];const prints=[];const warnings=[];const errors=[];const http=[];
  const capture=text=>{const s=String(text??'');if(s.length<20)return; if(isLua(s)||s.length>100){captures.push(s);mock.recorder.dynamicStrings.push({bytes:s.length,looksLikeLua:isLua(s)})}};
  const originalTable='';
  lua.global.game=mock.game;lua.global.workspace=mock.workspace;lua.global.script=mock.make('script');lua.global.Instance={new:(className)=>mock.make(`Instance.${className}`,{className,fresh:true})};lua.global.Enum=mock.make('Enum');lua.global.Vector2=(x=0,y=0)=>({X:x,Y:y});lua.global.Vector3=(x=0,y=0,z=0)=>({X:x,Y:y,Z:z});lua.global.CFrame=(...a)=>({args:a});lua.global.Color3=mock.make('Color3');lua.global.UDim=mock.make('UDim');lua.global.UDim2=mock.make('UDim2');lua.global.TweenInfo=mock.make('TweenInfo');lua.global.RaycastParams=mock.make('RaycastParams');lua.global.getgenv=()=>mock.make('_G');lua.global.getrenv=()=>mock.make('_G');lua.global.checkcaller=()=>true;lua.global.identifyexecutor=()=> 'analysis';lua.global.getexecutorname=()=> 'analysis';lua.global.firetouchinterest=(...a)=>mock.recorder.call('firetouchinterest',a);lua.global.task=mock.task;lua.global.wait=()=>0;lua.global.spawn=(fn,...a)=>{if(typeof fn==='function')try{fn(...a)}catch{}};lua.global.delay=(t,fn,...a)=>{if(typeof fn==='function')try{fn(...a)}catch{}};
  lua.global.print=(...a)=>prints.push(a.map(String).join('\t'));lua.global.warn=(...a)=>warnings.push(a.map(String).join('\t'));
  lua.global.__capture_code=capture;lua.global.__capture_concat=(s)=>{if(typeof s==='string'){built.push(s);capture(s)}return s};lua.global.__capture_http=(url)=>{http.push(String(url));mock.recorder.call('HTTP',[String(url)]);return ''};
  lua.global.WindUI={CreateWindow:(cfg)=>mock.make('WindUI.Window',{fresh:true}),Notify:(...a)=>mock.recorder.call('WindUI.Notify',a)};
  try{await lua.doString(`
    local _t=table
    table={}
    for k,v in pairs(_t) do table[k]=v end
    local _concat=_t.concat
    local _cap=__capture_concat
    table.concat=function(t,sep,i,j) local r=_concat(t,sep,i,j); if type(r)=='string' and _cap then pcall(_cap,r) end; return r end
    _t=nil
  `)}catch{}
  try{await lua.doString(`
    local _nativeLoad=load
    local _capLoad=function(chunk,...)
      if type(chunk)=='string' then pcall(__capture_code,chunk) end
      return _nativeLoad(chunk,...)
    end
    load=_capLoad
    loadstring=_capLoad
  `)}catch{}
  try{await lua.doString('os=nil;io=nil;package=nil;debug=nil;require=nil;dofile=nil;loadfile=nil;collectgarbage=function()end') }catch{}
  let runtimeError=null;
  if(mode!=='static'){
    try{await lua.doString(source)}catch(e){runtimeError=String(e?.message||e);errors.push(runtimeError)}
    for(const cb of mock.recorder.callbacks.slice(0,300)){
      for(const args of [[true],[false],['Weight'],['Any'],[68],[10]]){try{if(typeof cb.fn==='function')cb.fn(...args)}catch{}}
    }
  }
  const candidates=[...captures,...built].filter(isLua).map(normalize);
  const recovered=choose(candidates)||reconstruction({staticReport:st,runtime:{calls:mock.recorder.calls}});
  let formatted=recovered;try{formatted=luaFormat.Beautify(recovered,{RenameVariables:false,RenameGlobals:false,SolveMath:false,Indentation:'    '})}catch{}formatted=normalize(formatted);
  const exact=candidates.some(x=>x===formatted||x.trim()===formatted.trim());
  const quality=candidates.length?'high':'medium';
  const report={engineVersion:'4.0.0',recoveryKind:candidates.length?(exact?'captured-source':'captured-generated-source'):'runtime-reconstruction',recoveryQuality:quality,static:st,runtime:{error:runtimeError,captures:candidates.map(x=>({bytes:Buffer.byteLength(x)})),dynamicStrings:mock.recorder.dynamicStrings,prints,warnings,errors,calls:mock.recorder.calls.slice(0,10000),properties:mock.recorder.properties.slice(0,5000),callbacks:mock.recorder.callbacks.length,http},durationMs:Date.now()-started};
  fs.writeFileSync(output,formatted,'utf8');fs.writeFileSync(reportPath,JSON.stringify(report,null,2));try{await lua.global.close?.()}catch{}
}
main().catch(e=>{console.error(e.stack||e);process.exit(2)});
