function stripComments(source){
  const s=String(source||'');let out='';let i=0;let quote=null;
  while(i<s.length){
    if(!quote && s[i]==='-' && s[i+1]==='-'){
      if(s[i+2]==='['){const m=s.slice(i+2).match(/^\[(=*)\[/);if(m){const end=']'+m[1]+']';const p=s.indexOf(end,i+2+m[0].length);if(p<0)break;const raw=s.slice(i,p+end.length);out+='\n'.repeat((raw.match(/\n/g)||[]).length);i=p+end.length;continue;}}
      const p=s.indexOf('\n',i+2);out+=p<0?'': '\n';i=p<0?s.length:p+1;continue;
    }
    const c=s[i];if(c==='"'||c==="'"){quote=c;out+=c;i++;while(i<s.length){const x=s[i];out+=x;i++;if(x==='\\'&&i<s.length){out+=s[i++];continue}if(x===quote){quote=null;break}}continue}
    if(c==='['){const m=s.slice(i).match(/^\[(=*)\[/);if(m){const end=']'+m[1]+']';const p=s.indexOf(end,i+m[0].length);if(p>=0){out+=s.slice(i,p+end.length);i=p+end.length;continue}}}
    out+=c;i++;
  }
  return out.replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim()+'\n';
}
function clean(source){return stripComments(String(source||'')).replace(/^\s*--\[\[[\s\S]*?\]\]\s*/,'').trim()+'\n'}
function choose(candidates){
  const usable=(candidates||[]).filter(x=>typeof x==='string'&&x.trim().length>0).map(clean).filter(x=>!/^local\s+__lualens\s*=\s*\{\s*\}\s*$/m.test(x));
  usable.sort((a,b)=>score(b)-score(a)||b.length-a.length);return usable[0]||'';
}
function score(s){let n=0;n+=Math.min(30,s.length/2000);n+=(s.match(/game:GetService|game\.GetService/g)||[]).length*2;n+=(s.match(/WindUI|CreateWindow|Window:Tab/g)||[]).length*3;n+=(s.match(/FireServer|InvokeServer|Activate/g)||[]).length*2;n+=(s.match(/function\s*\(|local\s+function/g)||[]).length;n-=(s.match(/__lualens|VM|dispatcher|local\s+[A-Za-z]\s*=\s*function/g)||[]).length*2;return n}
function reconstruction({staticReport,runtime}){
  const calls=runtime?.calls||[];const lines=[];const services=[];for(const c of calls){if(c.name==='game.GetService'&&c.args?.[0]&&!services.includes(c.args[0]))services.push(c.args[0])}
  for(const s of services)lines.push(`local ${String(s).replace(/[^A-Za-z0-9_]/g,'_')} = game:GetService(${JSON.stringify(s)})`);
  if(services.length)lines.push('');
  const seen=new Set();for(const c of calls){if(!c?.name||seen.has(c.name))continue;seen.add(c.name);if(/GetService|Result|Connection|Child/.test(c.name))continue;const args=(c.args||[]).map(x=>typeof x==='string'?JSON.stringify(x):String(x)).join(', ');lines.push(`${c.name}(${args})`)}
  return clean(lines.join('\n'));
}
module.exports={stripComments,clean,choose,reconstruction};
