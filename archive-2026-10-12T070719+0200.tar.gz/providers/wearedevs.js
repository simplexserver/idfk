const fs=require('fs'),path=require('path'),os=require('os');
const {runEngine}=require('../engine/runner');
async function run({inputBuffer,originalName,timeoutMs,retries=0}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'simplex-wad-')); const input=path.join(dir,(originalName||'input.lua').replace(/[^a-zA-Z0-9._-]/g,'_'));
 fs.writeFileSync(input,inputBuffer);
 try{const r=await runEngine(input,{timeoutMs,retries}); if(!r.ok){const e=new Error(r.error||'Recovery failed');e.code=r.attempts?.some(x=>x.timedOut)?'ENGINE_TIMEOUT':'ENGINE_FAILED';throw e;}
 return {provider:'wearedevs',providerLabel:'WeAreDevs v1.0.0',engineVersion:'Deobf Engine 3.0',recovered:r.recovered,report:r.report,attempts:r.attempts,fingerprint:r.fingerprint,durationMs:r.durationMs};}
 finally{fs.rmSync(dir,{recursive:true,force:true});}
}
module.exports={name:'wearedevs',label:'WeAreDevs v1.0.0',run};
